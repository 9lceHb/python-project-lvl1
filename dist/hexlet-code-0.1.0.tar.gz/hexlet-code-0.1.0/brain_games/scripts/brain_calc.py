from brain_games.scripts.games import game_count


def main():
    game_count(3, 'calc')


if __name__ == '__main__':
    main()
